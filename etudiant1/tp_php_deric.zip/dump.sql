-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 28, 2024 at 10:49 AM
-- Server version: 10.11.4-MariaDB-1~deb12u1
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 1 - Database: `module6`
--

CREATE DATABASE module6;
CREATE USER 'administrationscolaire'@'localhost' IDENTIFIED BY 'P@ssw0rd1';
GRANT ALL ON module6.* TO 'administrationscolaire'@'localhost';
FLUSH PRIVILEGES;

-- --------------------------------------------------------

--
-- 2 - Table structure for table `etudiants`
--

CREATE TABLE `etudiants` (
  `id` int(11) PRIMARY KEY AUTO_INCREMENT ,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cv` text NOT NULL DEFAULT 'CV de l\'étudiant',
  `dt_naissance` date DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `dt_mis_a_jour` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 3 - Dumping data for table `etudiants`
--

INSERT INTO `etudiants` (`prenom`, `nom`, `email`, `cv`, `dt_naissance`, `isAdmin`, `dt_mis_a_jour`) VALUES
('Ryan', 'NAYR', 'RyanNAYR@Scolarite.fr', 'CV de l\'étudiant', NULL, 0, '2024-01-28 00:00:00'),
('Megane', 'GENAME', 'meganegename@scolarite.fr', 'CV de l\'étudiant', '2023-01-03', 0, '2024-01-28 00:00:00'),
('Ada', 'MEVE', 'Ada_meve@scolarite.fr', 'PHP\r\nMYSQL\r\nJS\r\nVAGRANT / DOCKER\r\n', '1960-12-31', 1, '2024-01-28 23:36:45'),
('ALAN', 'NALA', 'alan_nala@scolarite.fr', 'CV de l\'étudiant', NULL, 0, '2024-01-28 23:39:15'),
('Ryan', 'NAYR', 'RyanNAYR@Scolarite.fr', 'MONGODB\r\nHTML\r\nCSS\r\nJS', NULL, 0, '2024-01-28 23:47:52'),
('Megane', 'GENAME', 'meganegename@scolarite.fr', 'CV de l\'étudiant', '1960-12-31', 1, '2024-01-28 23:47:52'),
('Morgane', 'GORAME', 'morgane.gorame@scolarite.fr', 'CV de l\'étudiant', '1975-10-12', 0, '2020-12-17 23:38:20'),
('Arthur', 'MOYS', 'arthurmoys@scolarite.fr', 'CV de l\'étudiant', '2023-07-24', 0, '2024-01-28 23:47:52'),
('Harry', 'PORTER', 'peterporter@scolariite.fr', 'CV de l\'étudiant', '1985-06-03', 1, '2017-10-28 23:38:20'),
('Peter', 'PANNE', 'perterpanne@scolarite.fr', 'CV de l\'étudiant', '2023-04-05', 0, '2024-01-28 23:47:52');

