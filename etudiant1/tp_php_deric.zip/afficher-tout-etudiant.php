<?php
$dsn = "mysql://host=localhost;dbname=module6;charset=utf8";
$login = "administrationscolaire";
$password = "P@ssw0rd1";

$connexion = new PDO($dsn , $login , $password); 
// var_dump($connexion);
$stmt = $connexion->query("SELECT prenom, nom, email, cv, dt_naissance, isAdmin, dt_mis_a_jour FROM etudiants"); 

$tableau = $stmt->fetchAll(PDO::FETCH_ASSOC); 


echo "<table>
    <tr>
        <th>prenom</th>
        <th>nom</th>
        <th>email</th>
        <th>cv</th>
        <th>dt_naissance</th>
        <th>isAdmin</th>
        <th>dt_mis_a_jour</th>
    </tr>
";
foreach($tableau as $key => $value){
    echo "
        <tr>
            <td>$value[prenom]</td>
            <td>$value[nom]</td>
            <td>$value[email]</td>
            <td>$value[cv]</td>
            <td>$value[dt_naissance]</td>
            <td>$value[isAdmin]</td>
            <td>$value[dt_mis_a_jour]</td>
        </tr>
    ";
}
echo "</table>"; 

?>