<?php
$dsn = "mysql://host=localhost;dbname=module6;charset=utf8";
$login = "administrationscolaire";
$password = "P@ssw0rd1";
$connexion = new PDO($dsn , $login , $password); 
if (empty($_GET["id"]))
{
    echo "Identifiant erronné et / où non lié à un étudiant.";
} 
else
{
        $id= $_GET["id"];
        $stmt = $connexion->query("SELECT prenom, nom, email, cv, dt_naissance, isAdmin, dt_mis_a_jour FROM etudiants where id = $id"); 
        $tableau = $stmt->fetch(PDO::FETCH_ASSOC); 
    if(!empty($_POST)){
        $prenom = htmlentities($_POST["prenom"]);
        $nom = htmlentities($_POST["nom"]);
        $email = htmlentities($_POST["email"]);
        $cv = htmlentities($_POST["cv"]);
        $dtnaissance = str_replace('/', '-', htmlentities($_POST["dt_naissance"]));
        $isAdmin = boolval($_POST["isAdmin"]) == "true" ? '1' : '0';

        $update = "
            UPDATE etudiants 
            SET prenom = '$prenom', nom = '$nom', email = '$email', cv = '$cv', dt_naissance = '$dtnaissance ', isAdmin = '$isAdmin'
            WHERE id = $id
            ";

        $nbLigneUpdate = $connexion->exec($update);

        if($nbLigneUpdate > 0){
            $id= $_GET["id"];
            $connexion2 = new PDO($dsn , $login , $password); 
            $stmt2 = $connexion2->query("SELECT prenom, nom, email, cv, dt_naissance, isAdmin, dt_mis_a_jour FROM etudiants where id = $id"); 
            $tableau = $stmt2->fetch(PDO::FETCH_ASSOC); 
            echo "<br>Données Etudiant mis à jour";
        }
    }
}
?>

<fieldset><figcaption>Modifier fiche étudiant</figcaption>
<form method="post">
    <input type="hidden" name="id" id="id" value="<?php echo empty($_POST) ? $tableau["id"] : $_POST["id"] ;?>">
    <div>
        <label for="prenom">prenom</label>
        <input type="text" name="prenom" id="prenom" value="<?php echo empty($_POST)? $tableau["prenom"] : $_POST["prenom"] ?>">
    </div>
    <div>
        <label for="nom">nom</label>
        <input type="text" name="nom" id="nom" value="<?php echo empty($_POST) ? $tableau["nom"]  : $_POST["nom"]?>">
    </div>
    <div> 
        <label for="email">email</label>
        <input type="text" name="email" id="email" value="<?php echo empty($_POST) ?$tableau["email"] : $_POST["email"] ?>">
    </div>
    <div>
        <label for="cv">cv</label>
        <input type="text" name="cv" id="cv" value="<?php echo empty($_POST)? $tableau["cv"] : $_POST["cv"] ?>">
    </div>
    <div>
        <label for="dt_naissance">dt_naissance</label>
        <input type="text" name="dt_naissance" id="dt_naissance" value="<?php echo empty($_POST) ? $tableau["dt_naissance"] : $_POST["dt_naissance"] ?>">
    </div>
    <div>
        <label for="isAdmin">isAdmin</label>
        <input type="text" name="isAdmin" id="isAdmin" value="<?php echo  empty($_POST) ? $tableau["isAdmin"] : $_POST["isAdmin"] ?>">
    </div>
    <input type="submit" value="Modifier les informations étudiant">
</form>
</fieldset>

