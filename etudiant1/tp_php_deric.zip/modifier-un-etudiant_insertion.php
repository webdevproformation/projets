<?php
?>

<fieldset><figcaption>Insérer un nouvel Etudiant</figcaption>
<form method="post">
    <input type="hidden" name="id" id="id" value="<?php echo $tableau["id"] ?>">
    <div>
        <label for="prenom">prenom</label>
        <input type="text" name="prenom" id="prenom" value="<?php echo $tableau["prenom"] ?>">
    </div>
    <div>
        <label for="nom">nom</label>
        <input type="text" name="nom" id="nom" value="<?php echo $tableau["nom"] ?>">
    </div>
    <div> 
        <label for="email">email</label>
        <input type="text" name="email" id="email" value="<?php echo $tableau["email"] ?>">
    </div>
    <div>
        <label for="cv">cv</label>
        <input type="text" name="cv" id="cv" value="<?php echo $tableau["cv"] ?>">
    </div>
    <div>
        <label for="dt_naissance">dt_naissance</label>
        <input type="text" name="dt_naissance" id="dt_naissance" value="<?php echo $tableau["dt_naissance"] ?>">
    </div>
    <div>
        <label for="isAdmin">isAdmin</label>
        <input type="text" name="isAdmin" id="isAdmin" value="<?php echo $tableau["isAdmin"] ?>">
    </div>
    <input type="submit" value="Modifier les informations étudiant">
</fieldset>
</form>
<?php

if(!empty($_POST)){
    $dsn = "mysql://host=localhost;dbname=module6;charset=utf8";
    $login = "administrationscolaire";
    $password = "P@ssw0rd1";
    $connexion = new PDO($dsn , $login , $password); 

    $prenom = htmlentities($_POST["prenom"]);
    $nom = htmlentities($_POST["nom"]);
    $email = htmlentities($_POST["email"]);
    $cv = htmlentities($_POST["cv"]);
    $dtnaissance = str_replace('/', '', htmlentities($_POST["dt_naissance"]));
    $isAdmin = boolval($_POST["isAdmin"]) == "true" ? '1' : '0';
    $insertion = "INSERT INTO etudiants (prenom, nom, email, cv, dt_naissance, isAdmin) 
    VALUES ('$prenom', '$nom', '$email', '$cv','$dtnaissance', '$isAdmin')";

try {
    $connexion->exec($insertion);
    echo "Nouvel étudiant inséré en base de données";
} catch (\Throwable $th) {
    echo"données erronées veuilllez recommencer";
}
}

   
?>