<?php
$dsn = "mysql://host=localhost;dbname=module6;charset=utf8";
$login = "administrationscolaire";
$password = "P@ssw0rd1";
if (empty($_GET["id"]))
{
    echo "Merci de fournir l'identifiant souhaité en paramètre.";
} 
else{
    $id = $_GET["id"];

    $connexion = new PDO($dsn , $login , $password); 
    $stmt = $connexion->query("SELECT prenom, nom, email, cv, dt_naissance, isAdmin, dt_mis_a_jour FROM etudiants where id = $id"); 
    $tableau = $stmt->fetch(PDO::FETCH_ASSOC);
    if($tableau >0) {
        echo "<table>
            
        ";
        foreach($tableau as $key => $value){
            echo "
                <tr>
                    <th>$key</th>
                    <td> </td>
                    <td>$value</td>

                </tr>
            ";
        }
        echo "</table>"; 
    }
    else {
        echo "Aucun étudiant ne correspond à l'identifiant fourni.";
    }
    
}
?>