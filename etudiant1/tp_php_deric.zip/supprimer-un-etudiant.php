<?php
$dsn = "mysql://host=localhost;dbname=module6;charset=utf8";
$login = "administrationscolaire";
$password = "P@ssw0rd1";
$id= $_GET["id"];
if (!isset($id))
{
    echo "Merci de fournir l'identifiant souhaité en paramètre.";
} 
else{
    $connexion = new PDO($dsn , $login , $password); 
    $stmt = $connexion->exec("DELETE FROM etudiants where id = $id"); 
    if($stmt === 0) {
        echo "Aucun étudiant ne correspond à l'identifiant fourni.";
    }
    else {
        echo "Suppression Ok";
    }
}
?>